"use strict";

function rotateClockHands() {

}

setInterval(rotateClockHands, 1000);